# AI usage report — draft requiring student completion

**Name:** Mahdi Al Hashem — verify spelling  
**Student ID:** `202276640` — verify  
**Preparation date:** 19 October 2026  
**Submission/declaration date:** `[ENTER WHEN YOU ACTUALLY COMPLETE THE DECLARATION]`

## Tools and scope

**ChatGPT (coding assistant; exact model identifier not exposed in this conversation)** was used to analyze the provided assignment, generate the initial HTML/CSS/JavaScript, propose accessible UI behavior, implement error recovery, execute checks, revise generated code, and draft the README and documentation. The generated project should be treated as substantial AI assistance, not merely proofreading. Playwright, Python, and Node.js were execution/testing tools used by the assistant; they are not additional generative AI models.

**Claude (Anthropic; configured model `claude-opus-5-5`)** was used in a second conversation (C02) after Assignment 1 became available. It merged the real Assignment 1 content into the site (hero wording, About text, skills list, the Personal Portfolio and Study Planner cards with their original SVG images, a new `Concepts` filter, a `What changed since Assignment 1` panel, the © year footer), updated the unit and browser tests, ran the browser tests in Chromium, reviewed screenshots, and updated the README and docs.

The initial C01 prompt requested completion of the assignment with attention to the grading rubric. The source assignment was `portfolio assignment-2.md`. Assignment 1, the student ID, the linked institutional AI Usage Guidelines, and the student's own revisions were not supplied. The assistant cannot certify the student's understanding, attest that this is all AI use outside this conversation, or declare the work submission-ready.

## Usage log

Use one row per complete AI conversation. Add C02, C03, etc. for any later conversations or other AI tools; do not omit debugging, rewriting, or documentation assistance.

| ID | Tool (model) | Date | Purpose | Files affected | What you changed and how you verified it |
|---|---|---|---|---|---|
| C01 | ChatGPT (exact model identifier unavailable) | 2026-10-19 | Rubric analysis; initial site generation; accessibility, validation, error handling; testing and documentation | `index.html`, `css/styles.css`, `js/core.js`, `js/script.js`, `assets/images/favicon.svg`, `README.md`, `.gitignore`, `docs/*`, `tests/*`, `package.json` | **AI actions:** generated the implementation; extracted pure rules for dependency-free tests; checked boundaries, search, and sort; formatted source. Checks and limitations are recorded in `testing-report.md`. **Student actions:** `[REPLACE with your actual code changes and the tests you personally ran; none can be confirmed yet.]` |
| C02 | Claude (claude-opus-5-5) | 2026-10-19 | Integrate Assignment 1 into the C01 draft; update tests; run Chromium browser tests; update docs | `index.html`, `css/styles.css`, `js/script.js`, `assets/images/project-one.svg`, `assets/images/project-two.svg` (copied from A1), `tests/*`, `README.md`, `docs/*` | **AI actions:** see the Tools and scope section; results in `testing-report.md`. **Student actions:** `[REPLACE with what you reviewed, changed, and tested yourself.]` |

## Original generated artifacts

The separate evidence scaffold contains:

- `artifacts/A01-initial-website.zip`: the first generated HTML, CSS, JavaScript, favicon, and ignore file, saved before testing and subsequent revisions.
- `artifacts/A02-reviewed-project-before-student-edits.zip`: the delivered AI-generated project, including documentation and tests, before any student edits.
- `artifacts/manifest.txt`: SHA-256 checksums identifying those snapshots.
- `artifacts/A03-claude-integrated-project.zip` **(add this)**: the project exactly as Claude returned it in C02, before your own edits.

Preserve these originals. Put your own changes in the actual repository. Add further intermediate artifacts for any later AI assistance.

## Full conversation evidence — required and not yet included

1. Export **this entire conversation after the final response**, using the process in your course's AI Usage Guidelines. Include the prompt, replies, and generated artifacts/code in full; preserve the original export. The course's linked guidelines were not available in the attachment, so confirm their required export format yourself.
2. Add that export under `conversations/C01/` in the separate evidence folder. Include any other AI conversations under their corresponding IDs.
3. Do not substitute a summary or reconstructed transcript for a complete unedited export. The scaffold contains instructions, not an exported conversation.
4. Include the `artifacts/` directory and verify both directories in the ZIP.
5. Rename the completed ZIP to `202276640-MahdiAlHashem-assignment2-ai-evidence.zip` and upload it to Blackboard with the repository link. **Do not commit conversations, artifact snapshots, or the ZIP to GitHub.**

## Your own adaptation and understanding

The assignment requires student modification and understanding of AI output. Changes made by the assistant do not satisfy the requirement for your own work. Complete the following honestly after reviewing the code:

**My code improvement:** `[Describe one meaningful change you personally implemented, why it improves the site, the relevant file/function, and before/after behavior.]`

**My verification:** `[State exactly how you tested it and the actual result.]`

Useful options include extending the explorer to filter your real Assignment 1 technologies, adding a validated user preference of your own, or improving a genuine accessibility issue you identify. Choose something you understand; changing only the name or colors is weaker evidence of adaptation.

Be ready to answer in your own words:

1. Why does combining a search with a category use AND rather than OR?
2. What state changes when the user types in the search box?
3. Why does sorting use a copied array, and what restores Featured order?
4. What happens if `localStorage` throws? Why is the preference checked against two allowed values?
5. Why is `preventDefault()` necessary for the demo form?
6. Why trim whitespace? Why is client-side validation insufficient for a real backend?
7. How do `textContent`, `aria-describedby`, and focus movement help safety and usability?
8. What do the reduced-motion rules change? What still works without JavaScript?
9. Which lines did you personally change, and how do they build on Assignment 1?

These questions support learning; they are not a claim that the student has already answered them.

## Required declaration — unsigned template

**Complete this only after all statements are true.** The quotation below is the assignment's required wording, supplied as a template rather than an assertion made on your behalf.

> I declare that this report and the attached evidence document all of my AI use in this assignment, with complete and unedited conversations, and that I understand and can explain all the code I submitted. I understand that undeclared AI use or a false declaration will be treated as plagiarism according to KFUPM regulations.

**Name:** `[CONFIRM YOUR FULL NAME]`  
**Student ID:** `[ADD YOUR STUDENT ID]`  
**Date:** `[DATE YOU TRUTHFULLY MAKE THIS DECLARATION]`

Do not leave this as an unsigned draft in the final submission. The assignment says missing declaration or evidence results in zero. Never sign it before adding complete evidence and reviewing your own work.
